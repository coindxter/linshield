pref("general.config.obscure_value", 0);
pref("general.config.filename", "mozilla.cfg");